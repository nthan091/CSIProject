//
// Created by Ismail Ali, Zakariya Salad, and Jonathan Qinan Fan
//
#include "Beans.h"
#include <iostream>

// variable names for the beans
const std::string Green::name = "Green";
const std::string Soy::name = "Soy";

const std::string Black::name = "Black";
const std::string Red::name = "Red";

const std::string Garden::name = "Garden";
const std::string Blue::name = "Blue";

const std::string Chili::name = "Chili";
const std::string Stink::name = "Stink";


// METHOD GetCardsPerCoin tells how many cards are necessary to receive the corresponding number of coins.
// below is the method for all bean types

int Green::getCardsPerCoin(int numCards) {
	switch (numCards) {
	case 0:
	case 1:
	case 2:
		return 0;
	case 3:
	case 4:
		return 1;
	case 5:
		return 2;
	case 6:
		return 3;
	case 7:
	default:
		return 4;
	}
}

int Soy::getCardsPerCoin(int numCards) {
	switch (numCards) {
	case 0:
	case 1:
		return 0;
	case 2:
	case 3:
		return 1;
	case 4:
	case 5:
		return 2;
	case 6:
		return 3;
	case 7:
	default:
		return 4;
	}
}

int Black::getCardsPerCoin(int numCards) {
	switch (numCards) {
	case 0:
	case 1:
		return 0;
	case 2:
	case 3:
		return 1;
	case 4:
		return 2;
	case 5:
		return 3;
	case 6:
	default:
		return 4;
	}
}

int Red::getCardsPerCoin(int numCards) {
	switch (numCards) {
	case 0:
	case 1:
		return 0;
	case 2:
		return 1;
	case 3:
		return 2;
	case 4:
		return 3;
	case 5:
	default:
		return 4;
	}
}


int Blue::getCardsPerCoin(int numCards) {
	switch (numCards) {
	case 0:
	case 1:
	case 2:
	case 3:
		return 0;
	case 4:
	case 5:
		return 1;
	case 6:
	case 7:
		return 2;
	case 8:
	case 9:
		return 3;
	case 10:
		return 4;
	default:
		return 4;
	}
}

int Chili::getCardsPerCoin(int numCards) {
	switch (numCards) {
	case 0:
	case 1:
	case 2:
		return 0;
	case 3:
	case 4:
	case 5:
		return 1;
	case 6:
	case 7:
		return 2;
	case 8:
		return 3;
	case 9:
	default:
		return 4;
	}
}

int Stink::getCardsPerCoin(int numCards) {
	switch (numCards) {
	case 0:
	case 1:
	case 2:
		return 0;
	case 3:
	case 4:
	case 5:
		return 1;
	case 6:
	case 7:
		return 2;
	case 8:
		return 3;
	case 9:
	default:
		return 4;
	}
}


int Garden::getCardsPerCoin(int numCards) {
	switch (numCards) {
	case 0:
	case 1:
		return 0;
	case 2:
		return 2;
	case 3:
		return 3;
	default:
		return 3;
	}
}