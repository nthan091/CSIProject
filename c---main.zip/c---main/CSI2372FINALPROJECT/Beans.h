//
// Created by Ismail Ali, Zakariya Salad, and Jonathan Qinan Fan
//
#pragma once

#include <iostream>
#include <string>
#include "Card.h"


class Blue : public Card {
	const static std::string name;
public:
	virtual int getCardsPerCoin(int);

	virtual std::string getName() { return name; }

	virtual void print(std::ostream& out) { out << "B "; }
	
	static char getID() { return (name[0]); }
};

class Chili : public Card {
	const static std::string name;
public:
	virtual int getCardsPerCoin(int);

	virtual std::string getName() { return name; }

	virtual void print(std::ostream& out) { out << "C "; }

	static char getID() { return (name[0]); }
};


class Stink : public Card {
	const static std::string name;
public:
	virtual int getCardsPerCoin(int);
	
	virtual std::string getName() { return name; }

	virtual void print(std::ostream& out) { out << "S "; }

	static char getID() { return (name[0]); }
};

class Green : public Card {
	const static std::string name;
public:
	virtual int getCardsPerCoin(int);

	virtual std::string getName() { return name; }

	virtual void print(std::ostream& out) { out << "g "; }

	static char getID() { return (name[0]); }
};

class Soy : public Card {
	const static std::string name;
public:
	virtual int getCardsPerCoin(int);

	virtual std::string getName() { return name; }

	virtual void print(std::ostream& out) { out << "s "; }

	static char getID() { return (name[0]); }
};

class Red : public Card {
	const static std::string name;
public:
	virtual int getCardsPerCoin(int);

	virtual std::string getName() { return name; }

	virtual void print(std::ostream& out) { out << "R "; }

	static char getID() { return (name[0]); }
};

class Garden : public Card {
	const static std::string name;
public:
	virtual int getCardsPerCoin(int);
	virtual std::string getName() { return name; }

	virtual void print(std::ostream& out) { out << "G "; }

	static char getID() { return (name[0]); }
};


class Black : public Card {
	const static std::string name;
public:
	virtual int getCardsPerCoin(int);

	virtual std::string getName() { return name; }

	virtual void print(std::ostream& out) { out << "b "; }

	static char getID() { return (name[0]); }
};

