//
//  Created by Ismail Ali, Zakariya Salad, and Jonathan Qinan Fan
//

#include "Card.h"

std::ostream & operator << (std::ostream & out, Card& c) {
		c.print(out);
	return(out);
}

