//
//  Created by Ismail Ali, Zakariya Salad, and Jonathan Qinan Fan
//
#pragma once

#include <iostream>

class CardFactory;

class Card {
public:
// retrieves the amount of coins per card
	virtual int getCardsPerCoin(int) = 0;


	//out stream
	friend std::ostream& operator<<(std::ostream&, Card&);

	// retrieves the name of card ususally first index/letter
	virtual std::string getName() = 0;

	virtual void print(std::ostream&) = 0; 
};