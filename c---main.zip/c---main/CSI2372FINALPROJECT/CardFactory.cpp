//
// Created by Ismail Ali, Zakariya Salad, and Jonathan Qinan Fan
//

#include "CardFactory.h"

static CardFactory* instance;

CardFactory* CardFactory::getFactory() {
	
	if (instance == NULL)
	{
		instance = new CardFactory();
	}

	return instance;
}



Deck CardFactory::getDeck() {

	Deck d;

	for (int i = 0; i < 20; i++) {
		Blue* b = new Blue();//blue
		d.push_back(b);

		if (i < 18) {
			Chili* c = new Chili();
			d.push_back(c);
		}

		if (i < 16) {
			Stink* s = new Stink();
			d.push_back(s);
		}

		if (i < 14) {
			Green* g = new Green();
			d.push_back(g);
		}
		if (i < 12) {
			Soy* s = new Soy();
			d.push_back(s);
		}
		if (i < 10) {
			Black* b = new Black();
			d.push_back(b);
		}
		if (i < 8) {
			Red* ar = new Red();
			d.push_back(ar);
		}
		if (i < 6) {
			Garden* gr = new Garden();
			d.push_back(gr);
		}
	}

	srand(unsigned(time(NULL))); // Nécessaire pour un avoir un mélange différent à chaque instance
	random_shuffle(d.begin(), d.end());
	
	return d;
}
// Method that takes in string and creates a new instance of a bean class
Card * CardFactory::createCard(std::string &name) {
	if (name == "Stink") {
		return (new Stink);
	}
	if (name == "Green") {
		return (new Green);
	}
	if (name == "Garden") {
		return (new Garden);
	}
	if (name == "Soy") {
		return (new Soy);
	}
	if (name == "Blue") {
		return (new Blue);	
	};
	if (name == "Black") {
		return (new Black);
	}
	if (name =="Chili") {
		return (new Chili);
	}

	if (name == "Red") {
		return (new Red);
	}

	else {
		return nullptr;
	}
}
CardFactory::CardFactory() {}