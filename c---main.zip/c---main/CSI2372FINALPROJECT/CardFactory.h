//
// Created by Ismail Ali, Zakariya Salad, and Jonathan Qinan Fan
//
#pragma once

#include <vector>
#include <iostream>
#include <string>
#include <algorithm> 
#include <random>
#include <time.h>
#include "Card.h"
#include "Beans.h"
#include "Deck.h"

using namespace std;

class CardFactory {
	
public:
	CardFactory();

	//constructor in which all the cards need to be created in the numbers needed for the game
	CardFactory operator=(const CardFactory&) = delete;

	CardFactory(const CardFactory&) = delete;

	// returns a pointer to the only instance of CardFactory.
	static CardFactory* getFactory();
	
	//Returns a deck with all 104 bean cards.
	Deck getDeck();

	//Method that creates card
	Card* createCard(std::string &name);
	
};