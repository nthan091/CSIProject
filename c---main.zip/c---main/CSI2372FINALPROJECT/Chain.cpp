//
// Created by Ismail Ali, Zakariya Salad, and Jonathan Qinan Fan
//
#include "Chain.h"

Chain_all::Chain_all(char str) : type(str) {}

ostream & operator << (ostream & out, Chain_all &c) {
	c.print(out);
	return(out);
}

Chain_all & Chain_all::add(Card* card) {
	char c = card->getName()[0];
	if (c == 'B') {
		Chain<Blue>* chain = (Chain<Blue>*)(this);
		*chain += card;
	}
	else if (c == 'C') {
		Chain<Chili>* chain = (Chain<Chili>*)(this);
		*chain += card;
	}
	else if (c == 'S') {
		Chain<Stink>* chain = (Chain<Stink>*)(this);
		*chain += card;
	}
	else if (c == 'g') {
		Chain<Green>* chain = (Chain<Green>*)(this);
		*chain += card;
	}
	else if (c == 's') {
		Chain<Soy>* chain = (Chain<Soy>*)(this);
		*chain += card;
	}
	else if (c == 'b') {
		Chain<Black>* chain = (Chain<Black>*)(this);
		*chain += card;
	}
	else if (c == 'B') {
		Chain<Blue>* chain = (Chain<Blue>*)(this);
		*chain += card;
	}
	else if (c == 'G') {
		Chain<Garden>* chain = (Chain<Garden>*)(this);
		*chain += card;
	}
	if (c == 'R') {
		Chain<Red>* chain = (Chain<Red>*)(this);
		*chain += card;
	}
	return *this;
}

