//
// Created by Ismail Ali, Zakariya Salad, and Jonathan Qinan Fan
//
#include "Hand.h"
#include "CardFactory.h"
#include <sstream>
#include <iterator>

Hand::Hand() {}

Card * Hand::play() {
	try {
		if (isEmpty()) {
			throw (EmptyHand());
		}
		auto c = cards.front();
		cards.erase(cards.begin());
		return(c);
	}
	catch (EmptyHand& e) {
		std::cout << e.what() << endl;
	}
}

Card * Hand::operator[](int i) {
	try {
		if (isEmpty()) {
			throw (EmptyHand());
		}
		auto& c = cards[i];
		cards.erase(cards.begin() + i);
		return(c);
	}
	catch (EmptyHand& e) {
		std::cout << e.what() << endl;
	}
}

Card* Hand::show(int i) {
	return cards[i];
}

int Hand::getSize() {
	return cards.size();
}

Hand& Hand::operator+=(Card *c) {
	cards.push_back(c);
	return(*this);
}

Card * Hand::lastCardAdded() {
	try {
		if (isEmpty()) {
			throw (EmptyHand());
		}
		else return cards.back();
	}
	catch (EmptyHand& e) {
		std::cout << e.what() << endl;
	}
}

bool Hand::isEmpty() {
	return (cards.size() == 0);
}

Card * Hand::top() {
	try {
		if (isEmpty()) {
			throw (EmptyHand());
		}
		auto& c = cards.front();
		return(c);
	}
	catch (EmptyHand& e) {
		std::cout << e.what() << endl;
	}
}

Hand::Hand(istream & is, CardFactory * cf) {
	std::string allCards;

	getline(is, allCards);

	istringstream buf(allCards);
	istream_iterator<std::string> beg(buf), end;

	vector<std::string> cards(beg, end);
	for (std::string& name : cards) {
		std::string fullName;
		if (name == "B") {
			fullName = "Blue";
		}
		else if (name == "b") {
			fullName = "Black";
		}
		else if (name == "C") {
			fullName = "Chili";
		}
		else if (name == "S") {
			fullName = "Stink";
		}
		else if (name == "g") {
			fullName = "Green";
		}
		else if (name == "R") {
			fullName = "Red";
		}
		else if (name == "G") {
			fullName = "Garden";
		}
		else if (name == "s") {
			fullName = "Soy";
		}
		Card* c = ((*cf).createCard(fullName));
		if (c != NULL) {
			this->cards.push_back(c);
		}
	}
}