//
// Created by Ismail Ali, Zakariya Salad, and Jonathan Qinan Fan
//
#pragma once

#include "Card.h"
#include "Beans.h"
#include "CardFactory.h"
#include <iostream>

using namespace std;

// Exception
class EmptyHand : public exception {
public:
	virtual const char* what() const throw() {
		return "No cards in the hand.";
	}
};

// Class
class Hand {
	std::vector<Card*> cards;
public:
	Hand();
	Hand(istream&, CardFactory*);

	Card* play();
	Card* top();
	Card* operator[](int);
	Card* show(int);
	int getSize();
	Hand& operator+=(Card*);
	Card* lastCardAdded();
	bool isEmpty();

	friend ostream& operator<<(ostream& o, Hand& h) {
		for (auto card : h.cards) {
			if(card != nullptr) {
				o << *card << " ";
			}
		}
		cout << endl;
		return o;
	};
};
