//
// Created by Ismail Ali, Zakariya Salad, and Jonathan Qinan Fan
//
#include "TradeArea.h"
#include "CardFactory.h"
#include <sstream>
#include <iterator>

TradeArea & TradeArea::operator+=(Card *c) {
	listofCards.push_back(c);
	return *this;
}

bool TradeArea::legal(Card *c) {
	bool l = false;
	for (auto& it : listofCards) {
		if (it->getName() == c->getName()) {
			l = true;
		}
	}
	return l;
}

Card * TradeArea::trade(std::string str) {
	bool check = false;
	list<Card*>::iterator it;
	for (it = listofCards.begin(); it != listofCards.end(); it ++) {
		if (((*it)->getName() == str)) {
			check = true;
			auto c = *it;
			it = listofCards.erase(it);
			return c;
		}
	}
	if (!check) {
		std::cout << "No cards of this type" << endl;
	}
	return nullptr;
}

int TradeArea::numCards() {
	return listofCards.size();
}

bool TradeArea::isEmpty() {
	return (listofCards.size() == 0);
}

void TradeArea::getLast() {
	std::cout << *listofCards.back() << endl;
}

list<Card*>& TradeArea::getListofCards() {
	return listofCards;
}

TradeArea::TradeArea() {}

TradeArea::TradeArea(istream & is, CardFactory *cf) {

	std::string allCards;

	getline(is, allCards);

	istringstream buf(allCards);
	istream_iterator<std::string> beg(buf), end;

	vector<std::string> cards(beg, end);
	for (std::string& nom : cards) {
		Card* c = ((*cf).createCard(nom));
		if (c!=NULL)
			listofCards.push_back(c);
	}

}