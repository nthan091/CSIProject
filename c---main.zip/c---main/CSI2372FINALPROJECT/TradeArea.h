//
// Created by Ismail Ali, Zakariya Salad, and Jonathan Qinan Fan
//
#pragma once

#include <list>
#include <string>
#include "Beans.h"
#include "CardFactory.h"

using namespace std;

class TradeArea {
	list<Card *> listofCards;
public:
	TradeArea& operator += (Card*);
	bool legal(Card*);
	Card* trade(std::string);
	int numCards();
	bool isEmpty();
	void getLast();
	TradeArea(istream&, CardFactory*);
	list<Card *> & getListofCards();
	TradeArea();

	friend ostream& operator<<(ostream& out, const TradeArea& t) {
		if (t.listofCards.size() == 0) {
			out << "Trade Area is empty" << endl;
		}
		else {
			for (auto& c : t.listofCards) {
				out << c->getName() << " ";
			}
		}
		cout << endl;
		return out;
	};
};