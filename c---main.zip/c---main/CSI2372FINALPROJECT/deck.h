//
// Created by Ismail Ali, Zakariya Salad, and Jonathan Qinan Fan
//
#pragma once

#include <vector>
#include <iostream>
#include "Beans.h"

// EXCEPTION

class EmptyDeck : public std::exception {
public:
	virtual const char* what() const throw() {
		return "Cannot pick up a card -> Deck is Empty";
	}
};

class Deck: public std::vector<Card*> {
public:

	Deck();
	Deck(std::istream& is, CardFactory* cf);
	
	Card* draw();
	friend std::ostream& operator<<(std::ostream& os, const Deck& d) {
		for (int i = 0; i < d.size(); i++) {
			os << (*((Card*) d.at(i))).getName()<<" ";
		}
		return os;
	}
};
