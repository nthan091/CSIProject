//
// Created by Ismail Ali, Zakariya Salad, and Jonathan Qinan Fan
//

#include "DiscardPile.h"
#include "CardFactory.h"
#include <sstream>
#include <iterator>

DiscardPile::DiscardPile() {}

DiscardPile & DiscardPile::operator+=(Card * c) {
	(*this).push_back(c);
	return *this;
}

bool DiscardPile::isEmpty() {
	return ((*this).size() == 0);
}

Card * DiscardPile::pickUp() {
	if (isEmpty()) {
		cout << "Pile is Empty" << endl;
		return nullptr;
	}
	else {
		auto c = back();
		pop_back();
		return c;
	}
}

Card * DiscardPile::top() {
	return back();
}

DiscardPile::DiscardPile(istream & is, CardFactory *cf ) {
	std::string allCards;

	getline(is, allCards);


	istringstream buf(allCards);
	istream_iterator<std::string> beg(buf), end;

	vector<std::string> cards(beg, end);
	for (auto& name : cards) {
		Card* c = ((*cf).createCard(name));
		if (c != NULL)
			push_back(c);
	}
}

void DiscardPile::print(std::ostream & o) {
	if (isEmpty()) {
		o << "Pile is Empty" << endl;
	}
	else {
		o << (top())->getName() << endl;
	}
}