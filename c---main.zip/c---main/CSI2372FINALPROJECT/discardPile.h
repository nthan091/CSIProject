//
// Created by Ismail Ali, Zakariya Salad, and Jonathan Qinan Fan
//
#pragma once

#include "Beans.h"
#include "CardFactory.h"
#include <iostream>
#include <vector>

using namespace std;

class DiscardPile : public vector<Card*> {
public:
	DiscardPile();
	DiscardPile(istream&, CardFactory*);
	DiscardPile& operator += (Card*);
	bool isEmpty();
	Card* pickUp();
	Card* top();
	void print(std::ostream&);
	//void print(ostream&);

	friend ostream & operator << (ostream & o, DiscardPile & dp) {
		dp.print(o);
		return o;
	}
};
