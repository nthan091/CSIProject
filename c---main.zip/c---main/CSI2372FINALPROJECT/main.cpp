//
//  Created by Ismail Ali, Zakariya Salad, and Jonathan Qinan Fan
//

#include "Beans.h"
#include "Chain.h"
#include "Hand.h"
#include "Players.h"
#include "TradeArea.h"
#include "DiscardPile.h"
#include "Table.h"
#include <stdlib.h> 
#include <fstream>
#include <iostream>
#include <vector>

bool isYes(const std::string& str) {
	return ((str == "Y") || (str == "y"));
}

bool isAProperResponse(const std::string& str) {
	return (isYes(str) || (str == "N") || (str == "n"));
}


int main() {

	std::string response;

	
	CardFactory *cf;
	cf = CardFactory::getFactory();

	Deck* d;
	TradeArea* ta;
	DiscardPile* dp;
	Player* p1;
	Player* p2;
	Table* t;


	
	while (response != "N" && response != "S") {
		std::cout << "Do you want to start a (N)ew Game, or continue from a (S)ave?" << endl;
		getline(cin, response);
	}

	ifstream saveFile("SavedGame.txt");
	bool saveExists = saveFile.good();

	if (!saveExists && response=="S") {
		std::cout << "There is no game saved" <<endl << endl << "New game created" <<endl;
		response = "N";
	}
	if (response == "S") {

		ifstream tableSet ("SavedGame.txt");
		t = new Table(tableSet,cf);
		d = t->getDeck();
		ta = t->getTradeArea();
		dp = t->getDiscardPile();
		p1 = t->getPlayer1();
		p2 = t->getPlayer2();
		
		tableSet.close();
	}
	else {
		std::cout << endl << endl;

		// SETUP
		d = new Deck();
		ta = new TradeArea();
		dp = new DiscardPile();

		(*d) = cf->getDeck();
		std::string n1, n2;

		std::cout << "Enter the first player's name : " << endl;
		getline(cin, n1);
		std::cout << endl << "Enter the second player's name : " << endl;
		getline(cin, n2);

		p1 = new Player(n1);
		p2 = new Player(n2);

		(*p1).startHand((*d));
		(*p2).startHand((*d));

		t = new Table(p1, p2, d, dp, ta);
	}
		
		Player * currentPlpayer;

		// Core of Game

		while (!(*d).empty()) {
			currentPlpayer = t->changeTurn();
			std::cout << "---- PLayer Turn: " << currentPlpayer->getName() << endl << endl;
			std::cout << *t;

			currentPlpayer->drawCard((*d));
			std::cout << "You picked up: " << ((currentPlpayer->getHand())->lastCardAdded())->getName() << endl << endl;

			// The player plays the cards in the Trade area

			response.empty();

			if (!(*ta).isEmpty()) {
				std::cout << "Trade Area :" << endl;
				std::cout << (*ta);
				std::cout << endl << "Your chains :" << endl;
				currentPlpayer->printChains(std::cout);
				std::cout << endl;

				list<Card*>::iterator it = (*ta).getListofCards().begin();

				while (it != (*ta).getListofCards().end()) {
					response.empty();
					std::cout << "(A)dd " << (*it)->getName() << " to one of your chains, (T)hrow it out, or do (N)othing?" << endl;
					getline(cin, response);
					if (response == "A") {
						bool supp = currentPlpayer->playCard((*ta).trade((*(it++))->getName()), true);
					}
					if (response == "T") {
						(*dp) += ((*ta).trade((*(it++))->getName()));
					}
					if (response == "N") {
						it++;
					}
				}
			}

			// Le joueur joue la carte du haut de sa main

			std::cout << endl << endl << "Your hand is " << *(currentPlpayer->getHand()) << endl;
			std::cout << "You have to play the card at the top of the hand" << endl << endl;

			currentPlpayer->playCard((currentPlpayer->getHand())->play(), true);

			// Vente automatique des chaines

			currentPlpayer->sellAuto();

			// Le joueur peut jouer une nouvelle carte de sa main s'il le souhaite

			if (currentPlpayer->hasCard()) {
				currentPlpayer->playCard((currentPlpayer->getHand())->play(), false);
			}

			// Vente automatique des chaines

			currentPlpayer->sellAuto();

			response.empty();
			std::cout << endl << endl << "Your hand is : " << endl << *(currentPlpayer->getHand()) << endl;
			while (!isAProperResponse(response)) {
				response.empty();
				std::cout << "Do you want to throw out one of these cards? (Y)es/(N)o" << endl;
				getline(cin, response);
			}
			if (isYes(response)) {
				bool done = false;
				int i = 0;
				while ((i < (currentPlpayer->getHand())->getSize()) && !done) {
					response = "";
					while (!(isAProperResponse(response))) {
						std::cout << "Throw out " << *((currentPlpayer->getHand()))->show(i) << "? (Y)es/(N)o" << endl;
						getline(cin, response);
					}
					if (isYes(response)) {
						(*dp) += ((*(currentPlpayer->getHand()))[i]);
						done = true;
					}
					i++;
				}
			}

			// The player picks up 3 cards and places it in the Trade Area

			std::cout << endl << endl << "Draw 3 cards from the deck for the Trade Area" << endl << endl;

			for (int i = 0; i < 3; i++) {
				(*ta) += ((*d).draw());
				std::cout << "Card Drawn : ";
				(*ta).getLast();
			}

			while ((!(*dp).isEmpty()) && ((*ta).legal((*dp).top()))) {
				std::cout << "Added card of type " << (*dp).top()->getName() << " from the Discard Pile to the Trade Area" << endl;
				(*ta) += (*dp).pickUp();
			}

			std::cout << endl << endl;

			if (!(*ta).isEmpty()) {
				std::cout << "Trade Area :" << endl;
				std::cout << (*ta);
				std::cout << endl << "Your Chains :" << endl;
				currentPlpayer->printChains(std::cout);
				std::cout << endl;
				list<Card*>::iterator it = (*ta).getListofCards().begin();

				while (it != (*ta).getListofCards().end()) {
					response.empty();
					std::cout << "(A)dd " << (*it)->getName() << " to one of your chains or do (N)othing?" << endl;
					getline(cin, response);
					if (response == "A") {
						bool check = currentPlpayer->playCard((*ta).trade((*(it++))->getName()), false);
					}
					if (response == "N") {
						it++;

					}
				}
			}

			// Le joueur tire 2 cartes

			currentPlpayer->drawCard((*d));
			currentPlpayer->drawCard((*d));

			// Fin du tour

			std::cout << "Turn has ended for player: " << currentPlpayer->getName() << endl << endl << endl;
			if (d->size()!=0){
				response = "";
				std::cout << "Would you like to save the game? (Y)es/(N)o" << endl;
				getline(cin, response);
				if (isYes(response)) {

					ofstream savingFile;
					savingFile.open("SavedGame.txt");
					std::cout << savingFile.is_open();

					savingFile << (*d);
					savingFile << endl;

					savingFile << (*ta);

					savingFile << endl;
					(*dp).print(savingFile);

					bool tour = t->getTurn();

					savingFile << p1->getName() << " " << p1->getMaxNumChains() << " " << p1->getNumCoins() << endl;
					p1->printHand(savingFile, true);
					savingFile << endl;
					p1->printChains(savingFile);

					savingFile << p2->getName() << " " << p2->getMaxNumChains() << " " << p2->getNumCoins() << endl;
					p2->printHand(savingFile, true);
					savingFile << endl;
					p2->printChains(savingFile);

					savingFile << tour;

					savingFile.flush();
					savingFile.close();

					delete t;

					exit(0);
				}
			}
		}

		std::cout << " -- Game Ended -- " << endl;
		std::string winner;
		t->win(winner);
		std::cout << "The Winner is " << winner << endl << endl;
		std::cout << *t;

	return 0;
}