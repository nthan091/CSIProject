//
// Created by Ismail Ali, Zakariya Salad, and Jonathan Qinan Fan
//
#include "Players.h"
#include "Beans.h"

#include <fstream>
#include <iostream>
#include <sstream>
#include <iterator>
#include <string>

Player::Player(std::string & str) {
	hand = new Hand();
	name = str;
	numCoins = 2;
	numMaxChains = 2;
	numChains = 0;
}

Player::~Player() {
	delete hand;
}

Player::Player(istream & is, CardFactory * cf) {
	std::string getInfo;

	getline(is, getInfo);

	istringstream buf(getInfo);
	istream_iterator<std::string> beg(buf), end;

	vector<std::string> info(beg, end);
	name = info[0];
	numCoins = atoi(info[2].c_str());
	numMaxChains = atoi(info[1].c_str());

	hand = new Hand(is, cf);

	std::string chainStr;

	getline(is, chainStr);

	int blueNum=0;
	size_t nPosBlue = chainStr.find(" B ", 0); 
	while (nPosBlue != std::string::npos) {
		blueNum++;
		nPosBlue = chainStr.find(" Q ", nPosBlue + 1);
	}

	int blackNum=0;
	size_t nPosBlack = chainStr.find(" b ", 0);
	while (nPosBlack != std::string::npos) {
		blackNum++;
		nPosBlack = chainStr.find(" b ", nPosBlack + 1);
	}

	int chiliNum=0;
	size_t nPosChili = chainStr.find(" C ", 0); 
	while (nPosChili != std::string::npos) {
		chiliNum++;
		nPosChili = chainStr.find(" C ", nPosChili + 1);
	}

	int stinkNum=0;
	size_t nPosStink = chainStr.find(" S ", 0);
	while (nPosStink != std::string::npos) {
		stinkNum++;
		nPosStink = chainStr.find(" S ", nPosStink + 1);
	}

	int greenNum=0;
	size_t nPosGreen = chainStr.find(" g ", 0);
	while (nPosGreen != std::string::npos) {
		greenNum++;
		nPosGreen = chainStr.find(" g ", nPosGreen + 1);
	}

	int redNum=0;
	size_t nPosRed = chainStr.find(" R ", 0);
	while (nPosRed != std::string::npos) {
		redNum++;
		nPosRed = chainStr.find(" R ", nPosRed + 1);
	}

	int gardenNum=0;
	size_t nPosGarden = chainStr.find(" G ", 0);
	while (nPosGarden != std::string::npos) {
		gardenNum++;
		nPosGarden = chainStr.find(" G ", nPosGarden + 1);
	}

	int soyNum=0;
	size_t nPosSoy = chainStr.find(" S ", 0);
	while (nPosSoy != std::string::npos) {
		soyNum++;
		nPosSoy = chainStr.find(" S ", nPosSoy + 1);
	}

	
	std::string name;
	if (blueNum != 0) {
		name = "B";
		createNewChain(name);
		for (int i = 0; i < blueNum; i++) {
			Blue* b = new Blue();
			addCardToChain(b);
		}
	}
	if (blackNum != 0) {
		name = "b";
		createNewChain(name);
		for (int i = 0; i < blackNum; i++) {
			Black* b = new Black();
			addCardToChain(b);
		}
	}
	if (chiliNum != 0) {
		name = "C";
		createNewChain(name);
		for (int i = 0; i < chiliNum; i++) {
			Chili* c = new Chili();
			addCardToChain(c);
		}
	}

	if (stinkNum != 0) {
		name = "S";
		createNewChain(name);
		for (int i = 0; i < stinkNum; i++) {
			Stink* s = new Stink();
			addCardToChain(s);
		}
	}
	if (greenNum != 0) {
		name = "g";
		createNewChain(name);
		for (int i = 0; i < greenNum; i++) {
			Green* g = new Green();
			addCardToChain(g);
		}
	}
	if (redNum != 0) {
		name = "R";
		createNewChain(name);
		for (int i = 0; i < redNum; i++) {
			Red* r = new Red();
			addCardToChain(r);
		}
	}
	if (gardenNum != 0) {
		name = "G";
		createNewChain(name);
		for (int i = 0; i < gardenNum; i++) {
			Garden* g = new Garden();
			addCardToChain(g);
		}
	}
	if (soyNum != 0) {
		name = "S";
		createNewChain(name);
		for (int i = 0; i < soyNum; i++) {
			Soy* s = new Soy();
			addCardToChain(s);
		}
	}

	numChains = vectChain.size();

}

Chain_all& Player::operator[](int i) {
	return (*vectChain[i]);
}

void Player::buyThirdChain() {
	try {
		if (numCoins < 2) {
			throw(NotEnoughCoins());
		}
		if (numMaxChains == 3) {
			throw (MaxChainLimit());
		}
		numMaxChains++;
		numCoins -= 2;
	}
	catch (MaxChainLimit& e) {
		std::cout << e.what() << endl;
	}
	catch (NotEnoughCoins& e) {
		std::cout << e.what() << endl;
	}
}

void Player::printHand(ostream & o, bool tout) {
	if (!tout) {
		o << (*hand).top();
	}
	else {
		o << (*hand);
	}
}

void Player::startHand(Deck &d) {
	for (int i = 0; i < 5; i++) {
		(*hand) += d.draw();
	}
}

void Player::drawCard(Deck &d) {
	(*hand) += d.draw();
}

void Player::createNewChain(std::string& type) {
	char t = type.at(0);
	if (numChains == numMaxChains) {
		std::cout << "Maximum number of chains reached!" << endl;
	}

	else {
		switch (t) {
		case 'B':
			vectChain.push_back(new Chain<Blue>);
			break;
		case 'C':
			vectChain.push_back(new Chain<Chili>);
			break;
		case 'S':
			vectChain.push_back(new Chain<Stink>);
			break;
		case 'g':
			vectChain.push_back(new Chain<Green>);
			break;
		case 's':
			vectChain.push_back(new Chain<Soy>);
			break;
		case 'b':
			vectChain.push_back(new Chain<Black>);
			break;
		case 'R':
			vectChain.push_back(new Chain<Red>);
			break;
		case 'G':
			vectChain.push_back(new Chain<Garden>);
			break;
		}
		numChains++;
	}
}

void Player::addCardToChain(Card * c) {
	bool match = false;
	for (auto it : vectChain)
	{
		if (((*it).getType()) == c->getName().at(0) && !match) {
			(*it).add(c);
			match = true;
		}
	}
	if (!match) {
		std::cout << "No corresponding chain." << endl;
	}
}

bool Player::chainExists(Card * c) {
	bool match = false;
	for (auto it : vectChain)
	{
		if (((*it).getType()) == c->getName().at(0)) {
			match = true;
		}
	}
	if (match) {
		std::cout << "There exists a chain of type " << c->getName() << endl;
	}
	else {
		std::cout << "There does not exist a chain of type " << c->getName() << endl;
	}
	return match;
}

bool Player::playCard(Card * c, bool mandatory) {
	std::string response;
	if (!mandatory) {
		while ((response != "Y") && (response != "y") && (response != "N") && (response != "n")) {
			response.empty();
			std::cout << "Add a card " << c->getName() << " to your chains? (Y)es/(N)o" << endl;
			if (chainExists(c)) {
				printChains(std::cout);
				std::cout << "| (You have a chain of this type. You have " << (*this).getNumChains() << " out of " << (*this).getMaxNumChains() << " possible chains)" << endl << endl;
			}
			else {
				std::cout << "| (You do not have a chain of this type. You have " << (*this).getNumChains() << " out of " << (*this).getMaxNumChains() << " possible chains)" << endl << endl;
			}
			getline(cin, response);
		}
		if ((response == "N") || (response == "n")) {
			return false; 
		}
	}
	else {
		std::cout << "You have to add a card of type " << c->getName() << " to your chains" << endl;
	}
	
	if (chainExists(c)) {
		std::cout << "Card added to the already existing chain of type " << c->getName() << endl << endl;
		addCardToChain(c);
		std::cout << *this;
		return true;
	}
	else {
		std::string name = c->getName();
		if (getNumChains() < getMaxNumChains()) {
			createNewChain(name);
			addCardToChain(c);
			std::cout << "New chain created and card added" << endl << endl;
			std::cout << *this;
			return true;
		}
		if ((getMaxNumChains() == 2) && (getNumCoins() >= 2)) {
			cin.clear();
			response = "";
			while ((response != "Y") && (response != "y") && (response != "N") && (response != "n")) {
				std::cout << "Buy a new chain? (Y)es/(N)o" << endl;
				getline(cin, response);
			}
			if ((response == "Y") || (response == "y")) {
				buyThirdChain();
				createNewChain(name);
				addCardToChain(c);
				std::cout << "New chain bought and created and card added" << endl << endl;
				std::cout << *this;
				return true;
			}
		}
		std::cout << "You need to sell a chain" << endl;
		std::cout << *this;
		bool soldChain = false;
		while (!soldChain) {
			for (auto it = vectChain.begin(); it != vectChain.end(); it++) { 
				std::cout << endl << **it << endl;
				cin.clear();
				response = "";
				while ((response != "Y") && (response != "y") && (response != "N") && (response != "n")) {
					response = "";
					std::cout << "Would you like to sell this chain? You will get " << (*it)->sell() << " coin(s). (Y)es/(N)o" << endl;
					getline(cin, response);
				}
				if ((response == "Y") || (response == "y")) {
					int sellingPrice = (*it)->sell();
					(*this) += (*it)->sell();
					vectChain.erase(it);
					numChains--;
					createNewChain(name);
					addCardToChain(c);
					std::cout << "Chain sold for " << sellingPrice << " coins, new chain created and card added" << endl;
					std::cout << *this;
					return true;
				}
				response = "";
			}
			if (mandatory) {
				std::cout << endl << "  !!!!! You have to sell a chain !!!!!" << endl << endl << endl;
				
			}
			else {
				response.empty();
				while ((response != "Y") && (response != "y") && (response != "N") && (response != "n")) {
					response.empty();
					std::cout << "Don't sell the chain and cancel the addition of this card? (Y)es/(N)o" << endl;
					getline(cin, response);
				}
				if ((response == "Y") || (response == "y")) {
					std::cout << "Addition cancelled" << endl;
					return false;
				}
			}
		}
	}
}

bool Player::hasCard() {
	return (!(*hand).isEmpty());
}

void Player::printChains(ostream & o) {
	for (auto& ch : vectChain) {
		o << *ch;
	}
	o << endl;
}

void Player::sellAuto() {

	if (vectChain.size() > 0) {
		auto it = vectChain.begin();
		while (it != vectChain.end()) {
			if ((*it)->sellAuto()) {
				int sellingPrice = (*it)->sell();
				std::cout << endl << "Automatic selling of (max size) of the chain " << (*it)->getType() << " for " << sellingPrice << " coins " << endl << endl;
				(*this) += (*it)->sell();
				it = vectChain.erase(it);
				numChains--;
				printChains(std::cout);
			}
			else it++;
		}
	}
}

