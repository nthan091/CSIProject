//
// Created by Ismail Ali, Zakariya Salad, and Jonathan Qinan Fan
//
#pragma once

#include <iostream>
#include <vector>
#include "Chain.h"
#include "Hand.h"
#include "Card.h"

using namespace std;
// Exception

class NotEnoughCoins : public exception {
public:
	virtual const char* what() const throw() {
		return "Not enough coins";
	}
};

class MaxChainLimit : public exception {
public:
	virtual const char* what() const throw() {
		return "Already 3 chains";
	}
};

class Player {
	std::string name;
	int numCoins, numMaxChains, numChains;
	vector<Chain_all*> vectChain;
	Hand* hand;
public:
	Player(std::string&);
	Player(istream&, CardFactory*);
	~Player();
	void buyThirdChain();
	void printHand(ostream&, bool);
	void startHand(Deck &);
	void drawCard(Deck &);
	void createNewChain(std::string&);
	void addCardToChain(Card*);
	bool chainExists(Card *);
	bool playCard(Card *, bool);
	bool hasCard();
	void printChains(ostream &);
	void sellAuto();

	Chain_all& operator[](int);
	Player& operator+= (int n) { numCoins += n; return(*this); }


	std::string getName() { return name; }
	int getNumCoins() { return numCoins; }
	int getMaxNumChains() { return numMaxChains; }
	int getNumChains() { return numChains; }
	Hand* getHand() { return (hand); }

	friend ostream& operator<<(ostream& o, const Player& p) {
		o << p.name << "\n" << p.numCoins << " coins(s)" << endl;

		for (auto& ch : p.vectChain) {
			o << *ch;
		}
		o << endl << endl;
		return o;
	}
};