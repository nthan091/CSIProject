//
// Created by Ismail Ali, Zakariya Salad, and Jonathan Qinan Fan
//
#include "Table.h"
#include "CardFactory.h"
#include <sstream>
#include <iterator>

Table::Table(istream & is, CardFactory *cf) {
	carddeck = new Deck(is, cf);
	tradeArea = new TradeArea(is, cf);
	discardPile = new DiscardPile(is, cf);
	player1 = new Player(is, cf);
	player2 = new Player(is, cf);

	std::string turnSTR;

	getline(is, turnSTR);

	istringstream buf(turnSTR);
	istream_iterator<std::string> beg(buf), end;

	vector<std::string> turnVec(beg, end);

	if (!(turnVec.size()==0)) {
		const char* res = (turnVec[0].c_str());
		if (atoi(res) == 1) {
			turn = true;
		}
		else {
			turn = false;
		}
	}
}


bool Table::win(std::string & str) {
	if (carddeck->empty()) {
		int p1 = player1->getNumCoins();
		int p2 = player2->getNumCoins();
		if (p1 == p2) {
			str += "Equal";
			return (true);
		}
		str += (p1 > p2) ? player1->getName() : player2->getName();
		return (true);
	}
	else {
		return false;
	}
}


Table::Table(Player * p1, Player * p2, Deck * d, DiscardPile* dp, TradeArea * ta) {
	
	carddeck = d;
	
	discardPile = dp;
	tradeArea = ta;

	player1 = p1;
	player2 = p2;

	turn = true;
}


void Table::printHand(bool) {}

Player* Table::changeTurn() {
	if (turn) {
		turn = !turn;
		return (player1);
	}
	else {
		turn = !turn;
		return (player2);
	}
}

Player * Table::getPlayer1() {
	return player1;
}

Player * Table::getPlayer2() {
	return player2;
}

Deck * Table::getDeck() {
	return carddeck;
}


// deconstructor
Table::~Table() {
	delete player1;
	delete carddeck;
	delete discardPile;
	delete tradeArea;
	delete player2;
	
}

DiscardPile * Table::getDiscardPile() {
	return discardPile;
}

TradeArea * Table::getTradeArea() {
	return tradeArea;
}

bool Table::getTurn() {
	return turn;
}