//
// Created by Ismail Ali, Zakariya Salad, and Jonathan Qinan Fan
//
#pragma once

#include <string>
#include <iostream>
#include "Players.h"
#include "DiscardPile.h"
#include "TradeArea.h"
#include "CardFactory.h"

class Table {
	Player* player1;
	Player* player2;

	Deck* carddeck;
	DiscardPile* discardPile;
	
	TradeArea* tradeArea;
	bool turn;
public:
	Table(istream&, CardFactory*);
	Table(Player*, Player*, Deck*, DiscardPile*, TradeArea*);
	~Table();

	friend ostream& operator << (ostream & o, const Table &t) {
		o << "--------- PLAYERS ----------" << endl;
		o << *(t.player1) << endl << *(t.player2) << endl << endl;

		o << "--------- DISCARD PILE ---------" << endl;
		o << *(t.discardPile) << endl << endl;
		
		o << "--------- TRADE AREA ----------" << endl;
		o << *(t.tradeArea) << endl << endl;
		return o;
	}

	bool win(std::string&);
	void printHand(bool);

	Player* changeTurn();

	Player* getPlayer1();
	Player* getPlayer2();
	DiscardPile* getDiscardPile();

	TradeArea* getTradeArea();
	bool getTurn();
	Deck* getDeck();


	
};
