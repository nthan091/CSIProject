# c--

Run Makefile
